#ifndef STRING_H
#define STRING_H

#include "types.h"
uint32 strlength(string ch)
{


        uint32 i = 0;
        if(ch[0]=='\0')
          {
             return 0;
          }
        else
           {
              while(ch[i])
                {
                  i++;
                }
              return i;
           }
        
}

/* Added in episode 3*/ /*This function compares two strings and returns true (1) if they are equal or false (0) if they are not equal */

uint32 strEql(string ch1,string ch2)                     
{
        uint32 result = 1;
        uint32 size = strlength(ch1);
        if(1)
        {
        uint32 i = 0;
        for(i;i<size;i++)
        {
                if(ch1[i] != ch2[i]) 
                  {
                      result = 0;
                      break;
                  }
        }
        }
        return result;
}

string caseconvert(string s)
{


int i=0,l=strlength(s);
string res;
for(i=0;i<l;i++)
{
int asc=(int)s[i];

if(asc<97)
asc=asc+32;

res[i]=(char)asc;
  
}
res[i]='\0';
return res;



} 


uint8 atoi(string s){
	uint8 jj=0, res=0,temp=1, len=strlength(s);
	while(len--){
		temp=s[jj]-'0';
		uint8 x=len;
		while(x--){
			temp*=10;
		}
		res+=temp;
		jj++;
	}
	return res;
}



int substr(string ss,string s)
{
int flg=1,cnt=0;
int ll=(int)strlength(ss);
int l=(int)strlength(s);
if(l>ll)
  return -1;

int i=0,j=0,k;
	for(i=0;i+l<=ll;i++)
	{ 	 k=i;
		flg=1;
		for(j=0;j<l;j++)
		{
			if(ss[k+j]!=s[j])
			   {flg=0;}
		}

	if(flg==1)
	 {  cnt++;}


	}

return cnt;
}












#endif
